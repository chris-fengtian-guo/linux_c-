VS_SHADER_OUTPUT_HEADER_FILE
----------------------------

.. versionadded:: 3.10

Set filename for output header file containing object code of a ``.hlsl``
source file.
