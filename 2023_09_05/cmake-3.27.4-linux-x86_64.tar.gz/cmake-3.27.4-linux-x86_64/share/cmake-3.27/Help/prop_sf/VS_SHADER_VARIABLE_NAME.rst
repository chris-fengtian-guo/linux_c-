VS_SHADER_VARIABLE_NAME
-----------------------

.. versionadded:: 3.10

Set name of variable in header file containing object code of a ``.hlsl``
source file.
